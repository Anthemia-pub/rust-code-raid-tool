﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Code_Raider
{
    internal class Client : TcpClient
    {
        public TcpClient clients;
        public Client(TcpClient client)
        {
            clients = client;
        }
        public void SendCodesToMe(List<string> codes)
        {
            string message = string.Join(",", codes);
            byte[] data = System.Text.Encoding.UTF8.GetBytes(message);
            clients.GetStream().Write(data, 0, data.Length);
        }
    }
}
