﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Code_Raider
{
    internal class ConnectToServer
    {
        private TcpClient client;
        private string serverAddress;
        private int port;

        public ConnectToServer(string serverAddress, int port)
        {
            this.serverAddress = serverAddress;
            this.port = port;
            client = new TcpClient();
        }

        public void Connect()
        {
            try
            {
                client.Connect(serverAddress, port);
                Console.WriteLine("Connected to server.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error connecting to server: {ex.Message}");
            }
        }

        public void Disconnect()
        {
            if (client.Connected)
            {
                client.Close();
                Console.WriteLine("Disconnected from server.");
            }
        }
       public static Code_Manager codeswdadw;
        public void StartReadingCodes()
        {
            try
            {
                using (var stream = client.GetStream())
                {
                    using (var reader = new StreamReader(stream))
                    {
                        while (client.Connected)
                        {
                            string response = reader.ReadLine();
                            if (!string.IsNullOrEmpty(response))
                            {
                                List<string> codes = response.Split(',').ToList();
                                Console.WriteLine("Received codes: " + string.Join(", ", codes));
                                codeswdadw = new Code_Manager(codes);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading from server: {ex.Message}");
            }
        }
    }
}
