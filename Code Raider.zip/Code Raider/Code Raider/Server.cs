﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Code_Raider
{
    internal class Server
    {
        private TcpListener _listener;
        public List<Client> clients = new List<Client>();
        private List<string> predefinedCodes;

        public Server(string portforward, int port, List<string> codes)
        {
            IPAddress addy = IPAddress.Parse(portforward);
            _listener = new TcpListener(IPAddress.Any, port);
            predefinedCodes = codes;
        }

        public void Start()
        {
            _listener.Start();
            Console.WriteLine("Server started...");

            while (true)
            {
                var client = _listener.AcceptTcpClient();
                HandleClient(client);
            }
        }

        public void GiveCodesToCheck()
        {
            int clientCount = clients.Count;

            if (clientCount == 0) return;

            int codesPerClient = predefinedCodes.Count / clientCount;
            for (int i = 0; i < clientCount; i++)
            {
                var clientCodes = predefinedCodes.Skip(i * codesPerClient).Take(codesPerClient).ToList();
                foreach (var client in clients)
                {
                    client.SendCodesToMe(clientCodes); 
                }
            }
        }

        private void HandleClient(TcpClient client)
        {
            clients.Add(new Client(client));
        }
    }
}