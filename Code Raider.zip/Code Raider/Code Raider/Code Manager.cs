﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code_Raider
{
    internal class Code_Manager : List<string>
    {
        List<string> codess;
        public Code_Manager(List<string> codes)
        {
            codess = codes;
        }
        public int codeInt;
        public int GetLatestCode()
        {
            foreach (var code in codess)
            {
                return code[codeInt];
            }
            return 0;
        }
        public void nextcode()
        {
            codeInt++;
        }


    }

}
